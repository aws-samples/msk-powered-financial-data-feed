**Pre-requisites**
- Python environment already set up
- Run requirement.txt  pip install /path/to/requirement.txt

**Running script on Ec2**

1- Run the following command python3 ec2-live-script.py <arg1> <arg2>......<arg n>
    example: python3 ec2-live-script.py AAPL GOOGL

